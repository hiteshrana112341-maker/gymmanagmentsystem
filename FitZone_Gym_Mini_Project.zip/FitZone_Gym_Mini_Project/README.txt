FITZONE GYM MANAGEMENT SYSTEM
Mini Project: HTML, CSS and JavaScript

HOW TO RUN
1. Extract FitZone_Gym_Mini_Project.zip.
2. Open the folder in Visual Studio Code.
3. Open index.html in a browser, or use the VS Code Live Server extension.
4. Go to Register a Member and fill in the form.
5. Use Member Directory to search or delete records.

FILES
- index.html: page structure and content
- style.css: styling and responsive layout
- script.js: form validation, member listing, search, delete, and localStorage

FEATURES
- Responsive landing page and membership cards
- Register a member with name, 10-digit phone, plan and start date
- Duplicate phone-number validation
- Search by name or phone
- Delete member after confirmation
- Browser localStorage persistence

LIMITATIONS
This is a frontend-only educational mini project. It does not use a server or database.
Records are stored in the current browser only. Do not use real sensitive member data.
