const memberForm = document.getElementById("memberForm");
const memberTable = document.getElementById("memberTable");
const memberCount = document.getElementById("memberCount");
const searchInput = document.getElementById("searchInput");
const formMessage = document.getElementById("formMessage");
const planSelect = document.getElementById("plan");
const startDateInput = document.getElementById("startDate");

const planFees = {
  Basic: "₹999",
  Standard: "₹2,499",
  Premium: "₹8,999"
};

let members = [];

try {
  members = JSON.parse(localStorage.getItem("fitZoneMembers")) || [];
} catch (error) {
  members = [];
}

document.getElementById("year").textContent = new Date().getFullYear();
startDateInput.value = new Date().toISOString().slice(0, 10);

function saveMembers() {
  localStorage.setItem("fitZoneMembers", JSON.stringify(members));
}

function renderMembers(searchTerm = "") {
  const filteredMembers = members.filter(member =>
    member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.phone.includes(searchTerm)
  );

  memberCount.textContent = `${members.length} member${members.length === 1 ? "" : "s"}`;

  if (filteredMembers.length === 0) {
    memberTable.innerHTML = `<tr class="empty-row"><td colspan="6">${
      members.length === 0 ? "No members yet. Add your first member above." : "No matching members found."
    }</td></tr>`;
    return;
  }

  memberTable.innerHTML = filteredMembers.map(member => `
    <tr>
      <td><strong>${escapeHTML(member.name)}</strong></td>
      <td>${escapeHTML(member.phone)}</td>
      <td><span class="plan-pill">${escapeHTML(member.plan)}</span></td>
      <td>${escapeHTML(member.startDate)}</td>
      <td>${planFees[member.plan] || "—"}</td>
      <td><button class="delete-btn" data-id="${member.id}" aria-label="Delete ${escapeHTML(member.name)}">Delete</button></td>
    </tr>
  `).join("");
}

// Escape user-entered text before placing it into the table.
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[character]);
}

memberForm.addEventListener("submit", function (event) {
  event.preventDefault();

  const name = document.getElementById("name").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const plan = planSelect.value;
  const startDate = startDateInput.value;

  if (name.length < 2 || !/^[0-9]{10}$/.test(phone) || !plan || !startDate) {
    formMessage.style.color = "#ff9b8a";
    formMessage.textContent = "Please enter valid details in all fields.";
    return;
  }

  const duplicate = members.some(member => member.phone === phone);
  if (duplicate) {
    formMessage.style.color = "#ff9b8a";
    formMessage.textContent = "This phone number is already registered.";
    return;
  }

  members.unshift({
    id: Date.now().toString(),
    name,
    phone,
    plan,
    startDate
  });

  saveMembers();
  renderMembers(searchInput.value);
  memberForm.reset();
  startDateInput.value = new Date().toISOString().slice(0, 10);
  formMessage.style.color = "#8ee0a1";
  formMessage.textContent = "Member added successfully!";
});

searchInput.addEventListener("input", function () {
  renderMembers(searchInput.value);
});

memberTable.addEventListener("click", function (event) {
  const deleteButton = event.target.closest(".delete-btn");
  if (!deleteButton) return;

  const memberId = deleteButton.dataset.id;
  const member = members.find(item => item.id === memberId);
  if (!member) return;

  if (confirm(`Delete ${member.name} from the member list?`)) {
    members = members.filter(item => item.id !== memberId);
    saveMembers();
    renderMembers(searchInput.value);
    formMessage.style.color = "#8ee0a1";
    formMessage.textContent = "Member deleted.";
  }
});

document.querySelectorAll(".choose-plan").forEach(button => {
  button.addEventListener("click", function () {
    planSelect.value = this.dataset.plan;
    document.getElementById("register").scrollIntoView({ behavior: "smooth" });
    document.getElementById("name").focus({ preventScroll: true });
  });
});

renderMembers();
